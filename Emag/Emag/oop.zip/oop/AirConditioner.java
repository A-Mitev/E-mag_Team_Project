package oop;

public class AirConditioner extends HomeTech {
	private int bTUs;
	private int dbs;
	private boolean isSplit;
	
}
