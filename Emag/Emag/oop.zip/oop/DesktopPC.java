package oop;

public class DesktopPC extends Computer {
	private boolean isWaterCooled;
	private boolean isAllInOne;
	
	
}
