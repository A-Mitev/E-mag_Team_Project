package oop;

public abstract class SmartTech extends Product {
	private String mobileOS;
	private double displaySize;
	private int batteryCapacity;
	private boolean hasHeadphones;
	private boolean hasSDCard;
	
	
}
