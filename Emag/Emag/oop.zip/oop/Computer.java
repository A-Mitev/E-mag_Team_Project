package oop;

public abstract class Computer extends Product{
	private String operatingSystem;
	private String processor;
	private String graphics;
	private int ramMBs;
	private int hddCapacityGBs;
	private String usbType;
	
	
}
