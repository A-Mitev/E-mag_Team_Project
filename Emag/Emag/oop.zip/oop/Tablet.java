package oop;

public class Tablet extends SmartTech {
	private boolean hasSim;
	private boolean hasGPS;
	private boolean hasWebCam;
	
}
