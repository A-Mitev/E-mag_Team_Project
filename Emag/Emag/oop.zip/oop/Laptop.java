package oop;

public class Laptop extends Computer {
	private boolean hasTouchScreen;
	private double diplaySize;
	private double weight;
	private boolean hasWebcam;
	
	
}
