package oop;

public class HomeTheaterSystem extends AudioVisual {
	private int numberOfSpeakers;
	private int numberOfDiscs;
	private boolean THXCertified;
	private boolean bluRayCapable;
	//Outputs collection
}
