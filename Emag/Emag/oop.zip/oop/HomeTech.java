package oop;

public abstract class HomeTech extends Product {
	private int powerConsuptionInWatts;
	private boolean isBuiltIn;
	
}
