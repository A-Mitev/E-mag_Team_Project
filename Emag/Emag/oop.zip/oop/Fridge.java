package oop;

public class Fridge extends HomeTech {
	private int litres;
	private int numberOfDoors;
	private int numberOfShelves;
	private boolean hasFreezer;
	
	
}
