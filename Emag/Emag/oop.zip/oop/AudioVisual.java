package oop;

public abstract class AudioVisual extends Product {
	private int audioOutputPower;
	private boolean isWiFiCapable;
	private boolean hasRemoteControl;
	private boolean AVCablesBundled;
}
