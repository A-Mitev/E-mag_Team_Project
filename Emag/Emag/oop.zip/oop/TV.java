package oop;

public class TV extends AudioVisual {
	private int size;
	private boolean isLED;
	private boolean isSmart;
	private boolean isFullHD;
	//kolekciq za Inputs
}
