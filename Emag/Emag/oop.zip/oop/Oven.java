package oop;

public class Oven extends HomeTech {
	private boolean isGasPowered;
	private boolean hasAirFunction;
	private boolean hasTimer;
	
}
