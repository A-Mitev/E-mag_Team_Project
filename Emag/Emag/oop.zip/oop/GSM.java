package oop;

public class GSM extends SmartTech {
	private boolean hasDualSim;
	private boolean hasTouchScreen;
	
}
